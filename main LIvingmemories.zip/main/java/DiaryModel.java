package com.android.dt.livingmemories;

public class DiaryModel {

    String id,title,content,date;

    public DiaryModel(String id,String title,String content,String date){
        this.id=id;
        this.title=title;
        this.content=content;
        this.date=date;
    }

    public String getId(){ return id; }
    public String getTitle(){ return title; }
    public String getContent(){ return content; }
    public String getDate(){ return date; }
}