package com.android.dt.livingmemories;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class DiaryAdapter extends RecyclerView.Adapter<DiaryAdapter.ViewHolder>{

    Context context;
    ArrayList<DiaryModel> list;

    public DiaryAdapter(Context context,ArrayList<DiaryModel> list){
        this.context=context;
        this.list=list;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent,int viewType){

        View v= LayoutInflater.from(context)
                .inflate(R.layout.memories_item,parent,false);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder,int position){

        DiaryModel m=list.get(position);

        holder.title.setText(m.getTitle());
        holder.content.setText(m.getContent());
        holder.date.setText(m.getDate());

        // EDIT DIARY
        holder.edit.setOnClickListener(v->{

            Intent i=new Intent(context,Diary_page.class);

            i.putExtra("id",m.getId());
            i.putExtra("title",m.getTitle());
            i.putExtra("content",m.getContent());

            context.startActivity(i);
        });

        // DELETE ALERT
        holder.delete.setOnClickListener(v -> {

            new AlertDialog.Builder(context)
                    .setTitle("Delete Diary")
                    .setMessage("Are you sure you want to delete this diary?")
                    .setPositiveButton("YES", (dialog, which) -> {

                        deleteDiary(m.getId(), position);

                    })
                    .setNegativeButton("NO", null)
                    .show();
        });
    }

    @Override
    public int getItemCount(){
        return list.size();
    }

    // DELETE FUNCTION
    private void deleteDiary(String id,int position){

        StringRequest request = new StringRequest(
                Request.Method.POST,
                APIUrls.DELETE_DIARY,

                response -> {

                    try{

                        JSONObject obj=new JSONObject(response);

                        if(obj.getInt("status")==0){

                            list.remove(position);
                            notifyItemRemoved(position);

                            Toast.makeText(context,
                                    "Diary Deleted",
                                    Toast.LENGTH_SHORT).show();
                        }

                    }catch(Exception e){

                        Toast.makeText(context,
                                "Delete Error",
                                Toast.LENGTH_SHORT).show();
                    }

                },

                error -> Toast.makeText(context,
                        "Server Error",
                        Toast.LENGTH_SHORT).show()
        ){

            protected Map<String,String> getParams(){

                Map<String,String> params=new HashMap<>();
                params.put("id",id);

                return params;
            }
        };

        Volley.newRequestQueue(context).add(request);
    }

    class ViewHolder extends RecyclerView.ViewHolder{

        TextView title,content,date;
        ImageView edit,delete;

        ViewHolder(View v){
            super(v);

            title=v.findViewById(R.id.diary_title);
            content=v.findViewById(R.id.diary_content);
            date=v.findViewById(R.id.diary_date);

            edit=v.findViewById(R.id.edit);
            delete=v.findViewById(R.id.delete);
        }
    }
}