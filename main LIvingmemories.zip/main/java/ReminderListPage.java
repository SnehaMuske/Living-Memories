package com.android.dt.livingmemories;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ReminderListPage extends AppCompatActivity {

    RecyclerView recyclerView;
    ReminderAdapter adapter;
    ArrayList<Reminder> reminders;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reminder_list_page);

        recyclerView = findViewById(R.id.recyclerReminders);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        reminders = new ArrayList<>();

        // Get reminder from Intent (from Reminder_Calender_page)
        Reminder newReminder = (Reminder) getIntent().getSerializableExtra("newReminder");
        if (newReminder != null) {
            reminders.add(newReminder);
        }

        adapter = new ReminderAdapter(reminders);
        recyclerView.setAdapter(adapter);
    }
}
