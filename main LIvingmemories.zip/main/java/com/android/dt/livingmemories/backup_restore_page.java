package com.android.dt.livingmemories;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class backup_restore_page extends AppCompatActivity {

    Button btnBackup, btnRestore;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_backup_restore_page);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top,
                    systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize views
        btnBackup = findViewById(R.id.btnBackup);
        btnRestore = findViewById(R.id.btnRestore);
        progressBar = findViewById(R.id.progressBar);

        // Backup click
        btnBackup.setOnClickListener(v -> startBackup());

        // Restore click
        btnRestore.setOnClickListener(v -> startRestore());
    }

    // 🔐 Backup process
    private void startBackup() {
        progressBar.setVisibility(View.VISIBLE);
        Toast.makeText(this, "Backing up your diary...", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(() -> {
            progressBar.setVisibility(View.GONE);
            Toast.makeText(this,
                    "Backup completed successfully 💾",
                    Toast.LENGTH_LONG).show();
        }, 2000);
    }

    // 🔄 Restore process
    private void startRestore() {
        progressBar.setVisibility(View.VISIBLE);
        Toast.makeText(this, "Restoring diary entries...", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(() -> {
            progressBar.setVisibility(View.GONE);
            Toast.makeText(this,
                    "Diary restored successfully 📖",
                    Toast.LENGTH_LONG).show();
        }, 2000);
    }
}
