package com.android.dt.livingmemories;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class Dashboard extends AppCompatActivity {

    RecyclerView recyclerView;
    ImageView addNote;

    // Bottom menu icons
    ImageView iconDiary, iconCalendar, iconProfile, iconSettings;

    SearchView searchView;

    DiaryAdapter adapter;
    ArrayList<DiaryModel> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        recyclerView = findViewById(R.id.recyclerDiary);
        addNote = findViewById(R.id.add_note);

        // Bottom navigation icons
        iconDiary = findViewById(R.id.icon_diary);
        iconCalendar = findViewById(R.id.icon_calendar);
        iconProfile = findViewById(R.id.icon_profile);
        iconSettings = findViewById(R.id.icon_settings);

        searchView = findViewById(R.id.searchView);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        list = new ArrayList<>();
        adapter = new DiaryAdapter(this, list);
        recyclerView.setAdapter(adapter);

        // Add new diary
        addNote.setOnClickListener(v ->
                startActivity(new Intent(this, Diary_page.class)));

        // Bottom menu click events
        iconDiary.setOnClickListener(v ->
                startActivity(new Intent(this, Diary_page.class)));

        iconCalendar.setOnClickListener(v ->
                startActivity(new Intent(this, ReminderCalendarPage.class)));

        iconProfile.setOnClickListener(v ->
                startActivity(new Intent(this, My_profile.class)));

        iconSettings.setOnClickListener(v ->
                startActivity(new Intent(this, Settings.class)));

        // SEARCH FUNCTION
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {

            @Override
            public boolean onQueryTextSubmit(String query) {
                searchDiary(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {

                if(newText.isEmpty()){
                    loadData();
                }else{
                    searchDiary(newText);
                }

                return true;
            }
        });

        loadData();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadData();
    }

    // LOAD ALL DIARY
    private void loadData() {

        StringRequest request = new StringRequest(
                Request.Method.GET,
                APIUrls.FETCH_DIARY,

                response -> {

                    try {

                        JSONObject obj = new JSONObject(response);

                        if (obj.getInt("status") == 0) {

                            list.clear();

                            JSONArray arr = obj.getJSONArray("message");

                            for (int i = 0; i < arr.length(); i++) {

                                JSONObject o = arr.getJSONObject(i);

                                list.add(new DiaryModel(
                                        o.getString("id"),
                                        o.getString("title"),
                                        o.getString("content"),
                                        o.getString("date_created")
                                ));
                            }

                            adapter.notifyDataSetChanged();
                        }

                    } catch (Exception e) {

                        Toast.makeText(this,
                                "JSON Error: " + e.getMessage(),
                                Toast.LENGTH_LONG).show();
                    }

                },

                error -> Toast.makeText(this,
                        "Server Error: " + error.toString(),
                        Toast.LENGTH_LONG).show()
        );

        request.setRetryPolicy(new DefaultRetryPolicy(
                30000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        Volley.newRequestQueue(this).add(request);
    }

    // SEARCH DIARY
    private void searchDiary(String text){

        String url = APIUrls.SEARCH_DIARY + text;

        StringRequest request = new StringRequest(
                Request.Method.GET,
                url,

                response -> {

                    try{

                        JSONObject obj = new JSONObject(response);

                        if(obj.getInt("status")==0){

                            list.clear();

                            JSONArray arr = obj.getJSONArray("message");

                            for(int i=0;i<arr.length();i++){

                                JSONObject o = arr.getJSONObject(i);

                                list.add(new DiaryModel(
                                        o.getString("id"),
                                        o.getString("title"),
                                        o.getString("content"),
                                        o.getString("date_created")
                                ));
                            }

                            adapter.notifyDataSetChanged();
                        }

                    }catch(Exception e){

                        Toast.makeText(this,
                                "Search Error",
                                Toast.LENGTH_SHORT).show();
                    }

                },

                error -> Toast.makeText(this,
                        "Server Error",
                        Toast.LENGTH_SHORT).show()
        );

        Volley.newRequestQueue(this).add(request);
    }
}