package com.android.dt.livingmemories;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class HelpSupportActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_help_support);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top,
                    systemBars.right, systemBars.bottom);
            return insets;
        });

        // Call this method when needed (e.g., button click)
        // contactSupport();
    }

    // ✅ Method must be OUTSIDE onCreate
    private void contactSupport() {
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:support@livingmemories.com"));
        intent.putExtra(Intent.EXTRA_SUBJECT,
                "Living Memories - Help & Support");
        intent.putExtra(Intent.EXTRA_TEXT,
                "Hello Living Memories Team,\n\nI need help with the diary app.\n\nThank you.");
        startActivity(intent);
    }
}
