package com.android.dt.livingmemories;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Forgot_password extends AppCompatActivity {

    EditText edt_mobile_number;
    Button btn_send_pwd;
    TextView txt_return_to_login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_forgot_password);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Safe check for action bar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Request Password");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        edt_mobile_number = findViewById(R.id.fp_mobile_number);
        btn_send_pwd = findViewById(R.id.fp_send_pwd_btn);
        txt_return_to_login = findViewById(R.id.fp_login_link);

        txt_return_to_login.setOnClickListener(v -> {
            Intent login_activity = new Intent(Forgot_password.this, Login_page.class);
            startActivity(login_activity);
        });

        btn_send_pwd.setOnClickListener(v -> {
            String var_mobile_number = edt_mobile_number.getText().toString().trim();

            // Input validation
            if (var_mobile_number.isEmpty()) {
                edt_mobile_number.setError("Please enter mobile number");
                edt_mobile_number.requestFocus();
            } else if (var_mobile_number.length() != 10) {
                edt_mobile_number.setError("Please enter 10 digit mobile number");
                edt_mobile_number.requestFocus();
            } else {
                // API Calling
                String url = APIUrls.BASE_URL + "forgot-password.php";

                ProgressDialog progressDialog = new ProgressDialog(Forgot_password.this);
                progressDialog.setMessage("Processing...");
                progressDialog.setCancelable(false);
                progressDialog.show();

                RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());

                StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                        response -> {
                            progressDialog.dismiss();
                            try {
                                JSONObject jsonObject = new JSONObject(response);
                                int status = jsonObject.getInt("status");
                                String message = jsonObject.getString("message");

                                if (status == 0) {
                                    Toast.makeText(getApplicationContext(), "Success: " + message, Toast.LENGTH_SHORT).show();
                                    Intent activity = new Intent(Forgot_password.this, Login_page.class);
                                    startActivity(activity);
                                } else {
                                    Toast.makeText(getApplicationContext(), "Error: " + message, Toast.LENGTH_SHORT).show();
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                                Toast.makeText(getApplicationContext(), "JSON Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        },
                        error -> {
                            progressDialog.dismiss();
                            Toast.makeText(getApplicationContext(), "Network Error: " + error.toString(), Toast.LENGTH_LONG).show();
                        }) {
                    @Override
                    protected Map<String, String> getParams() {
                        Map<String, String> params = new HashMap<>();
                        params.put("mobile_no", var_mobile_number);
                        return params;
                    }
                };

                requestQueue.add(stringRequest);
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish(); // or onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
