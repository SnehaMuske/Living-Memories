package com.android.dt.livingmemories;

import java.io.Serializable;

public class Reminder implements Serializable {
    public String title;
    public String date;
    public String time;

    public Reminder(String title, String date, String time) {
        this.title = title;
        this.date = date;
        this.time = time;
    }
}
