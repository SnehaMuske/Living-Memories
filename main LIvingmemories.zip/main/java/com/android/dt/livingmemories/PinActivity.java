package com.android.dt.livingmemories;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class PinActivity extends AppCompatActivity {

    EditText pin1, pin2, pin3, pin4;
    Button btnVerify;
    TextView txtClick;
    String url = "http://10.0.2.2/dt_api/verify_pin.php"; // ✅ emulator IP

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pin);

        pin1 = findViewById(R.id.pin1);
        pin2 = findViewById(R.id.pin2);
        pin3 = findViewById(R.id.pin3);
        pin4 = findViewById(R.id.pin4);
        btnVerify = findViewById(R.id.btnVerify);
        txtClick = findViewById(R.id.txtClick);

        pin1.addTextChangedListener(new PinTextWatcher(pin1, pin2));
        pin2.addTextChangedListener(new PinTextWatcher(pin2, pin3));
        pin3.addTextChangedListener(new PinTextWatcher(pin3, pin4));

        txtClick.setOnClickListener(v -> startActivity(new Intent(PinActivity.this, SetPinActivity.class)));

        btnVerify.setOnClickListener(v -> {
            String pin = pin1.getText().toString() +
                    pin2.getText().toString() +
                    pin3.getText().toString() +
                    pin4.getText().toString();

            if (pin.length() == 4 && pin.matches("\\d{4}")) {
                verifyPin(pin);
            } else {
                Toast.makeText(this, "Enter Complete 4-digit PIN", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void verifyPin(String pin) {
        StringRequest request = new StringRequest(Request.Method.POST, url,
                response -> {
                    try {
                        JSONObject obj = new JSONObject(response);
                        String status = obj.getString("status");
                        if (status.equalsIgnoreCase("success")) {
                            Toast.makeText(this, "PIN Verified", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(this, Dashboard.class));
                            finish();
                        } else {
                            Toast.makeText(this, "Wrong PIN", Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        Toast.makeText(this, "Response Error", Toast.LENGTH_SHORT).show();
                        e.printStackTrace();
                    }
                },
                error -> Toast.makeText(this, "Network Error: " + error.getMessage(), Toast.LENGTH_SHORT).show()
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String,String> params = new HashMap<>();
                params.put("pin", pin);
                return params;
            }
        };

        // ✅ Timeout fix
        request.setRetryPolicy(new com.android.volley.DefaultRetryPolicy(
                10000, // 10 seconds
                com.android.volley.DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                com.android.volley.DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
        ));

        Volley.newRequestQueue(this).add(request);
    }

    private class PinTextWatcher implements TextWatcher {
        private final EditText current, next;
        PinTextWatcher(EditText current, EditText next) {
            this.current = current;
            this.next = next;
        }
        @Override
        public void afterTextChanged(Editable s) {
            if (s.length() == 1 && next != null) next.requestFocus();
        }
        @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
        @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
    }
}