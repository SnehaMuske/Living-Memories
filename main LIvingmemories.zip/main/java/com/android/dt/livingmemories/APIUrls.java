package com.android.dt.livingmemories;

public class APIUrls {

    // Emulator localhost
    public static final String BASE_URL = "http://10.0.2.2/dt_api/";

    public static final String INSERT_DIARY = BASE_URL + "insert_diary.php";
    public static final String FETCH_DIARY = BASE_URL + "fetch_diary.php";
    public static final String UPDATE_DIARY = BASE_URL + "update_diary.php";
    public static final String LOGIN_URL = BASE_URL + "login.php";
    public static final String SEARCH_DIARY =
            BASE_URL + "search_diary.php?search=";
    public static final String CHANGE_PASSWORD = BASE_URL + "changepassword.php";
    public static final String DELETE_DIARY = BASE_URL + "delete_diary.php";
    //public static final String SEARCH_DIARY = BASE_URL + "search_diary.php";
}