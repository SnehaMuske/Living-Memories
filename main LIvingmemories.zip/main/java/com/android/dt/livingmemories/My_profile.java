package com.android.dt.livingmemories;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class My_profile extends AppCompatActivity {

    TextView txt_reg_account, txt_reg_title, txt_reg_bcklog;
    EditText edt_Name, edt_EmailAddress, edt_Password, edt_Phone;
    Button bt_reg_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_my_profile);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        txt_reg_account = (TextView) findViewById(R.id.reg_account);
        txt_reg_bcklog = (TextView) findViewById(R.id.reg_bcklog);
        edt_Phone = (EditText) findViewById(R.id.Phone);
        edt_Password = (EditText) findViewById(R.id.Password);
        edt_EmailAddress = (EditText) findViewById(R.id.EmailAddress);
        edt_Name = (EditText) findViewById(R.id.Name);
        bt_reg_button = (Button) findViewById(R.id.reg_button);
        txt_reg_bcklog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intw=new Intent(My_profile.this, Dashboard.class);
                startActivity(intw);
            }
        });
        SharedPreferences prefs = getSharedPreferences("MyLogin", MODE_PRIVATE);
        String phone_no = prefs.getString("phone_no","");
        //API Calling
        String url = APIUrls.BASE_URL+"show-my-profile.php";

        //Define Progressdialogue and Show it
        ProgressDialog progressDialog = new ProgressDialog(My_profile.this);
        progressDialog.setMessage("Processing...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        //Create a new RequestQueue and define object
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                response -> {
                    try {
                        progressDialog.hide();

                        JSONObject jsonObject = new JSONObject(response);
                        int status = jsonObject.getInt("status");

                        if (status == 0) {
                            JSONObject data=jsonObject.getJSONObject("message");
                            int res_id= data.getInt("id");
                            String res_username= data.getString("username");
                            String res_email=data.getString("email");
                            String res_password=data.getString("password");
                            String res_phone_no=data.getString("phone_no");

                            edt_Phone.setText(res_phone_no);
                            edt_Password.setText(res_password);
                            edt_EmailAddress.setText(res_email);
                            edt_Name.setText(res_username);


                        } else {
                            String message=jsonObject.getString("message");
                            Toast.makeText(getApplicationContext(), "Error: " + message, Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(getApplicationContext(), "JSON Error: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                },
                error -> {
                    Toast.makeText(getApplicationContext(), "Error: " + error.toString(), Toast.LENGTH_LONG).show();
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("phone_no",phone_no);

                return params;
            }
        };
        requestQueue.add(stringRequest);



    }
}