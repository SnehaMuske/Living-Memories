package com.android.dt.livingmemories;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Change_password extends AppCompatActivity {

    EditText edt_current_pwd, edt_new_password, edt_confirm_password;
    Button btn_change_password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_change_password);

        SharedPreferences prefs = getSharedPreferences("MyLogin", MODE_PRIVATE);
        String session_mobile_number = prefs.getString("mobile_number", "");

        edt_current_pwd = findViewById(R.id.current_password);
        edt_new_password = findViewById(R.id.new_password);
        edt_confirm_password = findViewById(R.id.confirm_password);
        btn_change_password = findViewById(R.id.change_pwd_btn);

        btn_change_password.setOnClickListener(v -> {

            String var_current_password = edt_current_pwd.getText().toString().trim();
            String var_new_password = edt_new_password.getText().toString().trim();
            String var_confirm_password = edt_confirm_password.getText().toString().trim();

            if (var_current_password.isEmpty()) {
                edt_current_pwd.setError("Enter current password");
                return;
            }

            if (var_new_password.isEmpty()) {
                edt_new_password.setError("Enter new password");
                return;
            }

            if (var_confirm_password.isEmpty()) {
                edt_confirm_password.setError("Enter confirm password");
                return;
            }

            if (!var_new_password.equals(var_confirm_password)) {
                Toast.makeText(this,"Password not match",Toast.LENGTH_SHORT).show();
                return;
            }

            String url = APIUrls.CHANGE_PASSWORD;

            ProgressDialog progressDialog = new ProgressDialog(Change_password.this);
            progressDialog.setMessage("Processing...");
            progressDialog.show();

            RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());

            StringRequest stringRequest = new StringRequest(Request.Method.POST, url,

                    response -> {

                        progressDialog.dismiss();

                        try {

                            JSONObject obj = new JSONObject(response);
                            int status = obj.getInt("status");
                            String message = obj.getString("message");

                            if(status == 0){

                                Toast.makeText(getApplicationContext(),
                                        message,
                                        Toast.LENGTH_SHORT).show();

                                startActivity(new Intent(Change_password.this, My_profile.class));
                                finish();

                            }else{

                                Toast.makeText(getApplicationContext(),
                                        message,
                                        Toast.LENGTH_SHORT).show();
                            }

                        }catch(Exception e){
                            e.printStackTrace();
                        }

                    },

                    error -> {

                        progressDialog.dismiss();
                        Toast.makeText(getApplicationContext(),
                                error.toString(),
                                Toast.LENGTH_LONG).show();

                    })

            {
                @Override
                protected Map<String,String> getParams(){

                    Map<String,String> params = new HashMap<>();

                    params.put("phoneNo", session_mobile_number);
                    params.put("current_password", var_current_password);
                    params.put("new_password", var_new_password);
                    params.put("confirm_password", var_confirm_password);

                    return params;
                }
            };

            requestQueue.add(stringRequest);

        });
    }
}