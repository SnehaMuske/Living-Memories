package com.android.dt.livingmemories;

import static android.content.Context.MODE_PRIVATE;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;

public class BaseActivity extends AppCompatActivity {
    @Override
    protected void attachBaseContext(Context newBase)
    {
        SharedPreferences prefs=getSharedPreferences("LivingMemories",MODE_PRIVATE);
        String saved_language=prefs.getString("language","");
        if(!saved_language.isEmpty())
        {
            Locale locale=new Locale(saved_language);
            Locale.setDefault(locale);
            Configuration config = new Configuration();
            config.setLocale(locale);
            newBase = newBase.createConfigurationContext(config);


        }
        super.attachBaseContext(newBase);

    }
}
