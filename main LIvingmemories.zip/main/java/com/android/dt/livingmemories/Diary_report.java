package com.android.dt.livingmemories;


import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Diary_report extends AppCompatActivity {

    RecyclerView recyclerView;
    List<JSONObject> diaryList = new ArrayList<>();
    RecyclerView.Adapter<DiaryViewHolder> adapter;
    String fetchUrl = APIUrls.FETCH_DIARY;
    String deleteUrl = APIUrls.DELETE_DIARY;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diary_report);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        adapter = new RecyclerView.Adapter<DiaryViewHolder>() {
            @NonNull
            @Override
            public DiaryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.diary_item, parent, false);
                return new DiaryViewHolder(v);
            }

            @Override
            public void onBindViewHolder(@NonNull DiaryViewHolder holder, int position) {
                JSONObject obj = diaryList.get(position);
                try {
                    holder.txtTitle.setText("Title: " + obj.getString("title"));
                    holder.txtContent.setText("Content: " + obj.getString("content"));
                    holder.txtDate.setText("Date: " + obj.getString("date"));

                    holder.imgDelete.setOnClickListener(v -> {
                        try {
                            int id = obj.getInt("id");
                            String title = obj.getString("title");

                            AlertDialog dialog = new AlertDialog.Builder(Diary_report.this)
                                    .setTitle("Delete Confirmation")
                                    .setMessage("Are you sure you want to delete \"" + title + "\"?")
                                    .setPositiveButton("Delete", (d, which) -> deleteDiary(id, position))
                                    .setNegativeButton("Cancel", (d, which) -> d.dismiss())
                                    .create();

                            dialog.setOnShowListener(dialogInterface -> {
                                dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                                        .setTextColor(getResources().getColor(android.R.color.holo_red_dark));
                            });

                            dialog.show();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    });

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public int getItemCount() {
                return diaryList.size();
            }
        };

        recyclerView.setAdapter(adapter);

        loadDiaryData();
    }

    private void loadDiaryData() {
        RequestQueue queue = Volley.newRequestQueue(this);

        StringRequest request = new StringRequest(Request.Method.POST, fetchUrl,
                response -> {
                    try {
                        JSONObject obj = new JSONObject(response);
                        int status = obj.getInt("status");

                        if (status == 1) {
                            Toast.makeText(this, "No Diary Entries Found", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        JSONArray arr = obj.getJSONArray("message");
                        diaryList.clear();
                        for (int i = 0; i < arr.length(); i++) {
                            diaryList.add(arr.getJSONObject(i));
                        }

                        adapter.notifyDataSetChanged();

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                },
                error -> {
                    error.printStackTrace();
                    Toast.makeText(this, "Error: " + error.toString(), Toast.LENGTH_LONG).show();
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("fetch_diary", "2025-10-07"); // example date for testing
                return params;
            }

        };

        queue.add(request);
    }

    private void deleteDiary(int id, int position) {
        StringRequest request = new StringRequest(Request.Method.POST, deleteUrl,
                response -> {
                    try {
                        JSONObject obj = new JSONObject(response);
                        if (obj.getInt("status") == 0) {
                            Toast.makeText(Diary_report.this, "Deleted Successfully", Toast.LENGTH_SHORT).show();
                            diaryList.remove(position);
                            adapter.notifyItemRemoved(position);
                        } else {
                            Toast.makeText(Diary_report.this, obj.getString("message"), Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                },
                error -> Toast.makeText(Diary_report.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show()) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("id", String.valueOf(id)); // Send diary entry ID
                params.put("delete_diary", "1");     // Match with your PHP key
                return params;
            }
        };

        Volley.newRequestQueue(this).add(request);
    }

    static class DiaryViewHolder extends RecyclerView.ViewHolder {
        TextView txtTitle, txtContent, txtDate;
        ImageView imgDelete;

        DiaryViewHolder(View itemView) {
            super(itemView);
            txtTitle = itemView.findViewById(R.id.txtTitle);
            txtContent = itemView.findViewById(R.id.txtContent);
            txtDate = itemView.findViewById(R.id.txtDate);
            imgDelete = itemView.findViewById(R.id.imgdelete);
        }
    }
}
