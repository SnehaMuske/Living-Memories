package com.android.dt.livingmemories;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Settings extends AppCompatActivity {
    ImageView profileImage;
    TextView profileName, profileEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_settings);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        profileImage = findViewById(R.id.profile_image);
        profileName = findViewById(R.id.profile_name);
        profileEmail = findViewById(R.id.profile_email);

        // Load saved user info
        String name = getSharedPreferences("user_prefs", MODE_PRIVATE)
                .getString("name", "Guest");
        String email = getSharedPreferences("user_prefs", MODE_PRIVATE)
                .getString("email", "guest@example.com");

        // Set values in profile section
        profileName.setText(name);
        profileEmail.setText(email);
        LinearLayout whatsappBtn = findViewById(R.id.whatsapp_support_btn);

        whatsappBtn.setOnClickListener(v -> {

            String phoneNumber = "919325959571"; // Include country code, no +
            String message = "Hello, I need support";

            try {
                // WhatsApp URL
                String url = "https://wa.me/" + phoneNumber + "?text=" + Uri.encode(message);
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));
                intent.setPackage("com.whatsapp"); // Ensure WhatsApp opens
                startActivity(intent);

            } catch (Exception e) {
                // If WhatsApp not installed, show a message
                Toast.makeText(this, "WhatsApp not installed on this device", Toast.LENGTH_SHORT).show();
            }
        });

        // Account
        findViewById(R.id.account_settings).setOnClickListener(v ->
                startActivity(new Intent(this, My_profile.class)));

        // Notifications
        findViewById(R.id.notifications_settings).setOnClickListener(v ->
                startActivity(new Intent(this, ReminderCalendarPage.class)));

        // Privacy
        findViewById(R.id.privacy_settings).setOnClickListener(v ->
                startActivity(new Intent(this, PrivacyPolicyActivity.class)));

        // Help & Support
        findViewById(R.id.help_settings).setOnClickListener(v ->
                startActivity(new Intent(this, HelpSupportActivity.class)));

        // About App
        findViewById(R.id.about_settings).setOnClickListener(v ->
                startActivity(new Intent(this, AboutAppActivity.class)));

        // Change Password
        findViewById(R.id.change_password).setOnClickListener(v ->
                startActivity(new Intent(this, Change_password.class)));

        // Backup & Restore
        findViewById(R.id.backup_restore).setOnClickListener(v ->
                startActivity(new Intent(this, backup_restore_page.class)));

        // Share App
        findViewById(R.id.share_my_app).setOnClickListener(v -> {
            String sharemessage = "Living Memories\nDownload this awesome app\n\nDownload App From Play Store : https://play.google.com/store/apps/details?id=" + getPackageName();

            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_SUBJECT, "LivingMemories");
            intent.putExtra(Intent.EXTRA_TEXT, sharemessage);

            startActivity(Intent.createChooser(intent, "LM App Share Via"));
        });


        // Rate App
        findViewById(R.id.rate_my_app).setOnClickListener(v -> {
            Uri uri = Uri.parse("market://details?id=" + getPackageName());
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(intent);
        });
        findViewById(R.id.dial_a_phone_call_btn).setOnClickListener(v -> {
            String phoneNumber = "9325959571";

            Intent dialIntent = new Intent(Intent.ACTION_DIAL);
            dialIntent.setData(Uri.parse("tel:" + phoneNumber));
            startActivity(dialIntent);
        });


        findViewById(R.id.logout).setOnClickListener(v -> {
            new AlertDialog.Builder(Settings.this)
                    .setTitle("Exit App")
                    .setMessage("Are you sure you want to logout?")
                    .setPositiveButton("Yes", (dialog, which) -> {

                        // Clear SharedPreferences
                        SharedPreferences prefs =
                                getSharedPreferences("your_pref_name", MODE_PRIVATE);
                        SharedPreferences.Editor edit = prefs.edit();
                        edit.clear();
                        edit.apply();

                        // Go to Login page
                        Intent intent = new Intent(Settings.this, Login_page.class);
                        startActivity(intent);

                        // Close all previous activities
                        finishAffinity();
                    })
                    .setNegativeButton("No", (dialog, which) -> dialog.dismiss())
                    .show();
        });

    }
}
