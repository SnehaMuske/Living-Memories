package com.android.dt.livingmemories;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Registration_Screen extends AppCompatActivity {

    EditText edt_Name, edt_EmailAddress, edt_Password, edt_Phone;
    Button bt_reg_button;
    TextView txt_reg_bcklog;

    ProgressDialog progressDialog;
    Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_registration_screen);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        edt_Name = findViewById(R.id.Name);
        edt_Phone = findViewById(R.id.Phone);
        edt_EmailAddress = findViewById(R.id.EmailAddress);
        edt_Password = findViewById(R.id.Password);
        bt_reg_button = findViewById(R.id.reg_button);
        txt_reg_bcklog = findViewById(R.id.reg_bcklog);

        txt_reg_bcklog.setOnClickListener(v ->
                startActivity(new Intent(this, Login_page.class)));

        bt_reg_button.setOnClickListener(v -> registerUser());
    }

    private void registerUser() {

        String name = edt_Name.getText().toString().trim();
        String phone = edt_Phone.getText().toString().trim();
        String email = edt_EmailAddress.getText().toString().trim();
        String password = edt_Password.getText().toString().trim();

        // Validation
        if (name.isEmpty()) {
            edt_Name.setError("Enter name");
            return;
        }
        if (phone.length() != 10) {
            edt_Phone.setError("Enter 10 digit number");
            return;
        }
        if (email.isEmpty()) {
            edt_EmailAddress.setError("Enter email");
            return;
        }
        if (password.length() < 5) {
            edt_Password.setError("Minimum 5 characters");
            return;
        }

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Processing...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        // ⏱ FORCE STOP AFTER 5 SECONDS
        handler.postDelayed(() -> {
            if (progressDialog != null && progressDialog.isShowing()) {
                progressDialog.dismiss();
                Toast.makeText(this,
                        "Network timeout. Try again",
                        Toast.LENGTH_LONG).show();

                // 🔁 Go back to Login page
                startActivity(new Intent(this, Login_page.class));
                finish();
            }
        }, 5000);

        String url = APIUrls.BASE_URL + "registration_screen.php";
        Log.d("REGISTER_URL", url);

        RequestQueue queue = Volley.newRequestQueue(this);

        StringRequest request = new StringRequest(
                Request.Method.POST,
                url,
                response -> {
                    handler.removeCallbacksAndMessages(null);
                    progressDialog.dismiss();

                    Log.d("REGISTER_RESPONSE", response);

                    try {
                        JSONObject obj = new JSONObject(response);
                        int status = obj.getInt("status");
                        String message = obj.getString("message");

                        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();

                        // ✅ Always go to Login page after response
                        startActivity(new Intent(this, Login_page.class));
                        finish();

                    } catch (JSONException e) {
                        Toast.makeText(this,
                                "Invalid server response",
                                Toast.LENGTH_LONG).show();
                    }
                },
                error -> {
                    handler.removeCallbacksAndMessages(null);
                    progressDialog.dismiss();

                    Toast.makeText(this,
                            "Network error. Please login",
                            Toast.LENGTH_LONG).show();

                    Log.e("VOLLEY_ERROR", error.toString(), error);

                    // 🔁 Open Login page
                    startActivity(new Intent(this, Login_page.class));
                    finish();
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("username", name);
                params.put("phoneNo", phone);
                params.put("email", email);
                params.put("password", password);
                return params;
            }
        };

        // ⏱ VOLLEY TIMEOUT = 5 SECONDS
        request.setRetryPolicy(new DefaultRetryPolicy(
                5000, // 5 sec
                0,
                1.0f
        ));

        queue.add(request);
    }
}
