package com.android.dt.livingmemories;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Diary_page extends AppCompatActivity {

    EditText title,content;
    Button save;

    String id=null;

    protected void onCreate(Bundle b){

        super.onCreate(b);
        setContentView(R.layout.activity_diary_page);

        title=findViewById(R.id.text_id2);
        content=findViewById(R.id.text_id);
        save=findViewById(R.id.save_button1);

        if(getIntent().hasExtra("id")){

            id=getIntent().getStringExtra("id");

            title.setText(getIntent().getStringExtra("title"));
            content.setText(getIntent().getStringExtra("content"));

            save.setText("Update");
        }

        save.setOnClickListener(v->{

            if(id==null)
                insert();
            else
                update();
        });
    }

    private void insert(){

        StringRequest request=new StringRequest(
                Request.Method.POST,
                APIUrls.INSERT_DIARY,

                response->handleResponse(response),

                error->Toast.makeText(this,
                        "Insert Failed",
                        Toast.LENGTH_SHORT).show()
        ){

            protected Map<String,String> getParams(){

                Map<String,String> map=new HashMap<>();

                map.put("title",title.getText().toString());
                map.put("content",content.getText().toString());

                return map;
            }
        };

        Volley.newRequestQueue(this).add(request);
    }

    private void update(){

        StringRequest request=new StringRequest(
                Request.Method.POST,
                APIUrls.UPDATE_DIARY,

                response->handleResponse(response),

                error->Toast.makeText(this,
                        "Update Failed",
                        Toast.LENGTH_SHORT).show()
        ){

            protected Map<String,String> getParams(){

                Map<String,String> map=new HashMap<>();

                map.put("id",id);
                map.put("title",title.getText().toString());
                map.put("content",content.getText().toString());

                return map;
            }
        };

        Volley.newRequestQueue(this).add(request);
    }

    private void handleResponse(String res){

        try{

            JSONObject obj=new JSONObject(res);

            if(obj.getInt("status")==0){

                Toast.makeText(this,
                        obj.getString("message"),
                        Toast.LENGTH_SHORT).show();

                finish();
            }

        }catch(Exception e){

            Toast.makeText(this,
                    "Response Error",
                    Toast.LENGTH_SHORT).show();
        }
    }
}