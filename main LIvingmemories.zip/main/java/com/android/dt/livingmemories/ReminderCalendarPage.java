package com.android.dt.livingmemories;

import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Calendar;

public class ReminderCalendarPage extends AppCompatActivity {

    CalendarView calendarView;
    EditText edtReminder;
    TextView txtDate;
    Button btnTime, btnSave;
    int hour, minute;
    String selectedDate = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_reminder_calendar_page);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        calendarView = findViewById(R.id.calendarView);
        edtReminder = findViewById(R.id.edtReminder);
        txtDate = findViewById(R.id.txtDate);
        btnTime = findViewById(R.id.btnTime);
        btnSave = findViewById(R.id.btnSave);

        // Select date
        calendarView.setOnDateChangeListener((view, year, month, day) -> {
            selectedDate = day + "/" + (month + 1) + "/" + year;
            txtDate.setText("Selected Date: " + selectedDate);
        });

        // Time picker
        btnTime.setOnClickListener(v -> {
            Calendar c = Calendar.getInstance();
            hour = c.get(Calendar.HOUR_OF_DAY);
            minute = c.get(Calendar.MINUTE);

            TimePickerDialog timePickerDialog =
                    new TimePickerDialog(this,
                            (view, hourOfDay, minute1) -> {
                                hour = hourOfDay;
                                minute = minute1;
                                Toast.makeText(this, "Time: " + hour + ":" + minute, Toast.LENGTH_SHORT).show();
                            },
                            hour, minute, true);

            timePickerDialog.show();
        });

        // Save reminder and open list
        btnSave.setOnClickListener(v -> {
            String title = edtReminder.getText().toString().trim();
            if (title.isEmpty() || selectedDate.isEmpty()) {
                Toast.makeText(this, "Enter reminder and select date", Toast.LENGTH_SHORT).show();
                return;
            }

            String time = hour + ":" + minute;
            Reminder r = new Reminder(title, selectedDate, time);

            Intent intent = new Intent(ReminderCalendarPage.this, ReminderListPage.class);
            intent.putExtra("newReminder", r);
            startActivity(intent);
        });
    }
}
