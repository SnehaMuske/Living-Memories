package com.android.dt.livingmemories;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Locale;

public class Language_selection extends AppCompatActivity {
    Button btn_hindhi,btn_marathi,btn_english;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_language_selection);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        SharedPreferences prefs=getSharedPreferences("LivingMemories",MODE_PRIVATE);
        String saved_language=prefs.getString("language","");
        if(!saved_language.isEmpty())
        {
            Locale locale=new Locale(saved_language);
            Locale.setDefault(locale);
            Configuration config = new Configuration();
            config.setLocale(locale);
            getResources().updateConfiguration(config,getResources().getDisplayMetrics());
            Intent newActivity=new Intent(Language_selection.this, Login_page.class);
            startActivity(newActivity);
            finish();
        }
        btn_hindhi=(Button) findViewById(R.id.hindhi_btn);
        btn_marathi=(Button) findViewById(R.id.marathi_btn);
        btn_english=(Button) findViewById(R.id.english_btn);
        btn_hindhi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Locale locale=new Locale("hi");
                Locale.setDefault(locale);
                Configuration config = new Configuration();
                config.setLocale(locale);
                getResources().updateConfiguration(config,getResources().getDisplayMetrics());
                SharedPreferences prefs= getSharedPreferences("LivingMemories",MODE_PRIVATE);
                prefs.edit().putString("language","hi").apply();
                Intent newActivity=new Intent(Language_selection.this, Login_page.class);
                startActivity(newActivity);
                finish();
            }
        });
        btn_marathi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Locale locale=new Locale("mr");
                Locale.setDefault(locale);
                Configuration config = new Configuration();
                config.setLocale(locale);
                getResources().updateConfiguration(config,getResources().getDisplayMetrics());
                SharedPreferences prefs= getSharedPreferences("LivingMemories",MODE_PRIVATE);
                prefs.edit().putString("language","mr").apply();
                Intent newActivity=new Intent(Language_selection.this,Login_page.class);
                startActivity(newActivity);
                finish();
            }
        });
        btn_english.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Locale locale=new Locale("en");
                Locale.setDefault(locale);
                Configuration config = new Configuration();
                config.setLocale(locale);
                getResources().updateConfiguration(config,getResources().getDisplayMetrics());
                SharedPreferences prefs= getSharedPreferences("LivingMemories",MODE_PRIVATE);
                prefs.edit().putString("language","en").apply();
                Intent newActivity=new Intent(Language_selection.this,Login_page.class);
                startActivity(newActivity);
                finish();
            }
        });


    }
}