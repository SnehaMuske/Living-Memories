package com.android.dt.livingmemories;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class SetPinActivity extends AppCompatActivity {

    EditText pin1, pin2, pin3, pin4;
    Button btnSave;
    TextView txtClick1;

    // ✅ For emulator, 10.0.2.2 points to your PC localhost
    String saveUrl = "http://10.0.2.2/dt_api/save_pin.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_pin);

        pin1 = findViewById(R.id.pin1);
        pin2 = findViewById(R.id.pin2);
        pin3 = findViewById(R.id.pin3);
        pin4 = findViewById(R.id.pin4);
        btnSave = findViewById(R.id.btnSave);
        txtClick1 = findViewById(R.id.txtClick1);

        // Move focus automatically
        pin1.addTextChangedListener(new PinTextWatcher(pin1, pin2));
        pin2.addTextChangedListener(new PinTextWatcher(pin2, pin3));
        pin3.addTextChangedListener(new PinTextWatcher(pin3, pin4));

        txtClick1.setOnClickListener(v -> startActivity(new Intent(SetPinActivity.this, PinActivity.class)));

        btnSave.setOnClickListener(v -> {
            String pin = pin1.getText().toString() +
                    pin2.getText().toString() +
                    pin3.getText().toString() +
                    pin4.getText().toString();

            if (pin.length() == 4 && pin.matches("\\d{4}")) {
                savePin(pin);
            } else {
                Toast.makeText(this, "Enter a valid 4-digit numeric PIN", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void savePin(String pin) {
        StringRequest request = new StringRequest(Request.Method.POST, saveUrl,
                response -> {
                    response = response.trim();
                    if (response.equalsIgnoreCase("success")) {
                        Toast.makeText(this, "Pin Saved Successfully", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(SetPinActivity.this, PinActivity.class));
                        finish();
                    } else if (response.equalsIgnoreCase("exists")) {
                        Toast.makeText(this, "Pin already exists", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "Save Failed: " + response, Toast.LENGTH_LONG).show();
                    }
                },
                error -> Toast.makeText(this, "Network Error: " + error.toString(), Toast.LENGTH_LONG).show()
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String,String> params = new HashMap<>();
                params.put("pin", pin);
                return params;
            }
        };

        // ✅ Increase timeout to 10 seconds and retry policy
        request.setRetryPolicy(new com.android.volley.DefaultRetryPolicy(
                10000, // 10 seconds
                com.android.volley.DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                com.android.volley.DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
        ));

        Volley.newRequestQueue(this).add(request);
    }

    // Auto focus class
    private class PinTextWatcher implements TextWatcher {
        private final EditText current, next;
        PinTextWatcher(EditText current, EditText next) {
            this.current = current;
            this.next = next;
        }
        @Override
        public void afterTextChanged(Editable s) {
            if (s.length() == 1 && next != null) next.requestFocus();
        }
        @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
        @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
    }
}