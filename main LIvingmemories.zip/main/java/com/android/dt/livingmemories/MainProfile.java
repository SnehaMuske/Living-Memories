package com.android.dt.livingmemories;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainProfile extends AppCompatActivity {
    TextView profileDetails, settings, logout;
    Button btn_navigate,btn_share_my_app, btn_btnPay,btn_rate_my_app, btn_change_pwd_activity_btn,btn_dial_a_phone_call_btn,btn_share_whatsapp_btn,btn_Payment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main_profile);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        profileDetails = findViewById(R.id.profileDetails);
        settings = findViewById(R.id.settings);
        logout = findViewById(R.id.logout);
        btn_dial_a_phone_call_btn=(Button)findViewById(R.id.dial_a_phone_call_btn);
        btn_share_whatsapp_btn=(Button)findViewById(R.id.share_whatsapp_btn);

        btn_Payment=(Button)findViewById(R.id.Payment);
        btn_Payment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intw=new Intent(MainProfile.this, payment_getway.class);
                startActivity(intw);
            }
        });

        btn_share_whatsapp_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text="Welcome to living memories";
                Intent sentIntent =new Intent();
                sentIntent.setAction(Intent.ACTION_SEND);
                sentIntent.putExtra(Intent.EXTRA_TEXT,text);
                sentIntent.setType("text/plain");
                sentIntent.setPackage("com.whatsapp");
                try {
                    startActivity(sentIntent);
                }
                catch (ActivityNotFoundException ex)
                {
                    Toast.makeText(MainProfile.this, "Whatsapp not found in your device", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btn_dial_a_phone_call_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String phone_number="9325959571";
                Intent dialer =new Intent(Intent.ACTION_CALL);
                dialer.setData(Uri.parse("tel:" + phone_number));
                startActivity(dialer);
            }
        });

        SharedPreferences prefs = getSharedPreferences("MyLogin", MODE_PRIVATE);
        String mobile_no= prefs.getString("mobile_no", "");

        btn_share_my_app = findViewById(R.id.share_my_app);
        btn_rate_my_app = findViewById(R.id.rate_our_app);
        btn_change_pwd_activity_btn = findViewById(R.id.change_pwd_activity_btn);

        btn_change_pwd_activity_btn.setOnClickListener(v -> {
            Intent change_pwd_activity = new Intent(MainProfile.this, Change_password.class);
            startActivity(change_pwd_activity);
        });

        btn_share_my_app.setOnClickListener(v -> {
            String sharemessage = "Living Memories\nDownload this awesome app\n\nDownload App From Play Store : https://play.google.com/store/apps/details?id=" + getPackageName();

            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_SUBJECT, "LivingMemories");
            intent.putExtra(Intent.EXTRA_TEXT, sharemessage);

            startActivity(Intent.createChooser(intent, "LM App Share Via"));
        });

        btn_rate_my_app.setOnClickListener(v -> {
            Uri uri = Uri.parse("market://details?id=" + getPackageName());
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(intent);
        });

        profileDetails.setOnClickListener(v -> {
            Intent register = new Intent(MainProfile.this,My_profile.class);
            startActivity(register);
        });

        settings.setOnClickListener(v -> {
            Toast.makeText(this, "Settings Clicked", Toast.LENGTH_SHORT).show();
        });
        logout.setOnClickListener(v -> {
            new AlertDialog.Builder(MainProfile.this)
                    .setTitle("Exit App")
                    .setMessage("Are you sure to exit?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        SharedPreferences.Editor edit = prefs.edit();
                        edit.clear();
                        edit.apply();

                        Intent next_activity = new Intent(MainProfile.this, Login_page.class);
                        startActivity(next_activity);
                        finishAffinity();
                    })

                    .setNegativeButton("No", null)
                    .show();
        });
    }
}