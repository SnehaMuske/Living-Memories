package com.android.dt.livingmemories;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Login_page extends AppCompatActivity {

    EditText edt_mobile, edt_password;
    Button btn_login;
    TextView txt_forgot, txt_register;

    ProgressDialog progressDialog;
    RequestQueue requestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);

        edt_mobile = findViewById(R.id.mobile);
        edt_password = findViewById(R.id.Password);
        btn_login = findViewById(R.id.button);
        txt_forgot = findViewById(R.id.forgotpassword);
        txt_register = findViewById(R.id.registration);

// 🔵 Open Registration Page
        txt_register.setOnClickListener(v -> {
            Intent intent = new Intent(Login_page.this, Registration_Screen.class);
            startActivity(intent);
        });

// 🔵 Open Forgot Password Page
        txt_forgot.setOnClickListener(v -> {
            Intent intent = new Intent(Login_page.this,Forgot_password.class);
            startActivity(intent);
        });

        requestQueue = Volley.newRequestQueue(this);

        btn_login.setOnClickListener(v -> loginUser());
    }

    private void loginUser() {

        String phone = edt_mobile.getText().toString().trim();
        String password = edt_password.getText().toString().trim();

        if (phone.length() != 10) {
            edt_mobile.setError("Enter valid mobile number");
            return;
        }

        if (password.length() < 5) {
            edt_password.setError("Password too short");
            return;
        }

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Processing...");
        progressDialog.setCancelable(false);
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(
                Request.Method.POST,
                APIUrls.LOGIN_URL,
                response -> {
                    progressDialog.dismiss();
                    try {
                        JSONObject jsonObject = new JSONObject(response);

                        if (jsonObject.getInt("status") == 0) {

                            SharedPreferences sp =
                                    getSharedPreferences("MyLogin", MODE_PRIVATE);
                            sp.edit().putString("phone_no", phone).apply();

                            Toast.makeText(this,
                                    "Login Successful",
                                    Toast.LENGTH_SHORT).show();

                            startActivity(new Intent(Login_page.this,PinActivity.class));
                            finish();

                        } else {
                            Toast.makeText(this,
                                    jsonObject.getString("message"),
                                    Toast.LENGTH_LONG).show();
                        }

                    } catch (Exception e) {
                        Toast.makeText(this,
                                "Invalid server response",
                                Toast.LENGTH_LONG).show();
                        Log.e("JSON_ERROR", e.toString());
                    }
                },
                error -> {
                    progressDialog.dismiss();
                    Toast.makeText(this,
                            "Network or server error",
                            Toast.LENGTH_LONG).show();
                    Log.e("VOLLEY_ERROR", error.toString());
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("phone_no", phone);
                params.put("password", password);
                return params;
            }
        };

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                15000, // 15 seconds timeout
                0,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
        ));

        requestQueue.add(stringRequest);
    }
}
